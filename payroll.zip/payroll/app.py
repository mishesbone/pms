from app import create_app, db
from app.models import Level, Grade, Position, Department, Role, Permission, PayCode, Employee, User, Company

if __name__ == "__main__":
    # Initialize your Flask app and database
    app = create_app()
    with app.app_context():
        db.create_all()

        # Create default levels, grades, and positions
        default_levels = Level.create_defaults()
        default_grades = Grade.create_defaults()
        default_positions = Position.create_defaults()
        default_departments = Department.create_defaults()
        default_roles_and_permissions = Role.create_defaults()

        # Fetch or create a company object by name
        company_name = 'Company A'  # Replace with your company's name
        company = Company.query.filter_by(name=company_name).first()

        if company is None:
            # Create the default company if it doesn't exist
            default_company = Company(
                name='Company A',
                num_employees=100,
                business_email='dave@roboteknologies.org',
                payment_verification_status='Verified',
                is_enabled=True
            )
            db.session.add(default_company)
            db.session.commit()
            company = default_company

        # Continue with your logic, e.g., creating default paycodes
        default_paycodes = PayCode.create_defaults(company)
        if not Employee.query.first():
            Employee.create_defaults(company)

        db.session.commit()
        print("Default paycodes created successfully.")

    app.run(debug=True)
