import os
import random
import string
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail
from .config import Config
from flask_migrate import Migrate
#from flask_wtf.csrf import CSRFProtect 
from flask_login import LoginManager
from flask_restful import Api
from flask_bcrypt import Bcrypt
import pymssql
#from flask_user import UserManager, UserMixin, SQLAlchemyAdapter
from .models import User
# Initialize extensions outside of create_app for now
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
mail = Mail()
#csrf = CSRFProtect()
api = Api()

bcrypt = Bcrypt()
# Initializing SQLAlchemyAdapter and UserManager
#db_adapter = SQLAlchemyAdapter(db, User)
#user_manager = UserManager()



#Import your User model

from app.models import User 


def create_app(config_class=Config):
    # Generates a random string of characters for added uniqueness
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    app = Flask(__name__)
    app.config.from_object(config_class)


    # Initialize extensions with the app instance
    db.init_app(app)
    migrate.init_app(app,db)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.signin'  # Specifies the login view
    mail.init_app(app)
    api.init_app(app)
    bcrypt.init_app(app)
    #csrf.init_app(app)
    # Initializing SQLAlchemyAdapter and UserManager
    #user_manager.init_app(app,db_adapter=db_adapter)



    @login_manager.user_loader
    def load_user(user_id):
        # Implements logic to load a user by their ID, e.g., from the database
        return User.query.get(int(user_id))  


    # Import and register blueprints, error handlers, and other app components here
    from app.auth import auth_bp as auth_blueprint
    from app.admin import admin_bp as admin_blueprint
    from app.dashboard import dashboard_bp as dashboard_blueprint
    from app.main import main_bp as main_blueprint
    from app.departments import departments_bp as departments_blueprint
    from app.benefits import benefits_bp as benefits_blueprint
    from app.deductions import deductions_bp as deductions_blueprint
    from app.employee_card import employee_card_bp as employee_card_blueprint
    from app.pay_code import pay_code_bp as paycode_blueprint
    from app.positions import positions_bp as positions_blueprint
    from app.monthly_payroll import monthly_payroll_bp as monthly_payroll_blueprint
    from app.settings import settings_bp as settings_blueprint
    from app.payroll_reporting import payroll_reporting_bp as payroll_reporting_blueprint
    from app.salary_scale import salary_scale_bp as salary_scale_bp
    from app.pay_slips import pay_slips_bp as payslips_blueprint

    app.register_blueprint(auth_blueprint,url_prefix='/auth')
    app.register_blueprint(admin_blueprint, url_prefix='/admin')
    app.register_blueprint(dashboard_blueprint,url_prefix='/dashboard')
    app.register_blueprint(main_blueprint,url_prefix='/main')
    app.register_blueprint(departments_blueprint, url_prefix='/departments')
    app.register_blueprint(monthly_payroll_blueprint,url_prefix='/monthly_payroll')
    app.register_blueprint(settings_blueprint,url_prefix='/settings')
    app.register_blueprint(payroll_reporting_blueprint,url_prefix='/payroll_reporting')
    app.register_blueprint(benefits_blueprint,url_prefix='/benefits')
    app.register_blueprint(deductions_blueprint,url_prefix='/deductions')
    app.register_blueprint(employee_card_blueprint,url_prefix='/employee_card')
    app.register_blueprint(positions_blueprint,url_prefix='/positions')
    app.register_blueprint(salary_scale_bp,url_prefix='/salary_scale')
    app.register_blueprint(payslips_blueprint,url_prefix='/payslips')
    app.register_blueprint(paycode_blueprint,url_prefix='/pay_code')



    return app

from app.models import *  

