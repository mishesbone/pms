from flask import render_template, flash, redirect, url_for
from flask_login import login_required, current_user
from . import admin_bp
from ..models import User, db, SystemAdmin, Role,roles_users,Company
from ..forms import AdminForm,RoleAssignmentForm,RoleEditForm,CompanySelectionForm
from functools import wraps
from flask_wtf import FlaskForm
from wtforms import SelectField, SubmitField
from wtforms.validators import DataRequired
from wtforms.fields import SelectMultipleField
from wtforms.validators import DataRequired
from flask import render_template, request, redirect, flash


# Define a custom decorator to check if the current user has admin permissions
def admin_required(func):
    @wraps(func)  # This ensures that the decorated function keeps its name and docstring
    def decorated_view(*args, **kwargs):
        if current_user.is_authenticated and (current_user.has_permission('admin') or current_user.is_admin):
            return func(*args, **kwargs)
        else:
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('dashboard.dashboard', company_id=current_user.company_id))
    return decorated_view


@admin_bp.route('/users', endpoint='admin_users')
@login_required
@admin_required
def admin_users():
    # Admin user management logic goes here
    users = User.query.all()
    return render_template('users.html', users=users)
# Route for the admin dashboard
@admin_bp.route('/<int:user_id>', methods=['GET', 'POST'], endpoint='admin_dashboard')
@login_required
@admin_required
def admin_dashboard(user_id):
    company_selection_form = CompanySelectionForm() 
    company_id = current_user.company_id
    if company_selection_form.validate_on_submit():
        selected_company_id = company_selection_form.company.data

    
    # Query to retrieve user names and role names
    user_role_query = db.session.query(
        User.name.label('user_name'),
        Role.name.label('role_name'),
        User.id.label('user_id'),  
        Role.id.label('role_id')  
    ).join(
        roles_users,
        User.id == roles_users.c.user_id
    ).join(
        Role,
        Role.id == roles_users.c.role_id
    )

    # Execute the query and fetch the results
    user_role_assignments = user_role_query.all()

    # Check if the current user is an admin
    is_admin = current_user.is_admin

    # Initialize the RoleAssignmentForm with user and role choices
    role_assignment_form = RoleAssignmentForm(
        user_choices=[(user.id, user.name) for user in User.query.all()],
        role_choices=[(role.id, role.name) for role in Role.query.all()]
    )

    role_edit_form = RoleEditForm()  # Initialize the RoleEditForm

    if is_admin:
        # Handle role assignment to other users
        if request.method == 'POST':
            # Process the form data and assign roles to other users
            if role_assignment_form.validate_on_submit():
                # Get the selected user and roles from the form data
                selected_user_id = role_assignment_form.user.data
                selected_roles = role_assignment_form.roles.data

                # Fetch the user and roles from the database
                user = User.query.get(selected_user_id)
                roles = Role.query.filter(Role.id.in_(selected_roles)).all()

                # Assign the selected roles to the user
                user.roles = roles  # Adjust the attribute based on your User model
                db.session.commit()
                flash('Roles assigned to the user successfully.', 'success')

        # Handle role editing, role deleting, and role assigning
        if role_edit_form.validate_on_submit():
            selected_user_id = user_id  # The user to edit roles for
            selected_role_id = role_edit_form.role.data
            action = role_edit_form.action.data

            # Fetch the user and role from the database
            user = User.query.get(selected_user_id)
            role = Role.query.get(selected_role_id)

            if action == 'edit':
                # Edit the role (modify role attributes here)
                # role.name = updated_name
                db.session.commit()
                flash('Role updated successfully.', 'success')

            elif action == 'delete':
                # Remove the role from the user
                user.roles.remove(role)
                db.session.commit()
                flash('Role deleted from the user.', 'success')

            elif action == 'assign':
                # Assign the role to the user
                user.roles.append(role)
                db.session.commit()
                flash('Role assigned to the user.', 'success')

    return render_template('admin_dashboard.html',company_selection_form=company_selection_form, is_admin=is_admin, role_assignment_form=role_assignment_form, role_edit_form=role_edit_form, user_role_assignments=user_role_assignments,company_id=company_id)

# Route for editing roles
@admin_bp.route('/edit_role/<string:user_name>/<string:role_name>', methods=['GET', 'POST'], endpoint='edit_role')
@login_required
@admin_required
def edit_role(user_name, role_name):

    # Query the user and role objects based on their names
    user = User.query.filter_by(name=user_name).first()
    role = Role.query.filter_by(name=role_name).first()

    if not user or not role:
        # Handle cases where user or role with the given name does not exist
        flash('User or Role not found', 'error')
        return redirect(url_for('admin.admin_dashboard'))  # Redirect to the admin dashboard or another appropriate page

    # Create a form to edit the role
    form = RoleEditForm()

    if form.validate_on_submit():
        # Process the form data for role editing
        new_role_name = form.role_name.data  # Replace with the actual form field name
        # Update the role attributes with new data
        role.name = new_role_name  # Modify role attributes as needed
        db.session.commit()
        flash('Role updated successfully.', 'success')

    return render_template('edit_role.html', user=user, role=role, form=form)

# Route for deleting roles
@admin_bp.route('/delete_role/<int:user_id>/<int:role_id>', methods=['POST'], endpoint='delete_role')
@login_required
@admin_required
def delete_role(user_id, role_id):
    # Get the user and role
    user = User.query.get(user_id)
    role = Role.query.get(role_id)

    if user and role:
        user.roles.remove(role)
        db.session.commit()
        flash(f"Role '{role.name}' deleted from user '{user.name}'", 'success')
    else:
        flash("Role or user not found", 'danger')

    return redirect(url_for('admin.admin_dashboard', user_id=user_id))
    
# Route for assigning roles
@admin_bp.route('/assign_role/<int:user_id>', methods=['POST'], endpoint='assign_role')
@login_required
@admin_required
def assign_role(user_id):
    # Get the user from the user_id provided in the URL
    user = User.query.get(user_id)

    if user:
        role_id = request.form.get('role_id')  # Retrieve the selected role ID from the form
        role = Role.query.get(role_id)

        if role:
            user.roles.append(role)
            db.session.commit()
            flash(f"Role '{role.name}' assigned to user '{user.name}'", 'success')
        else:
            flash("Role not found", 'danger')
    else:
        flash("User not found", 'danger')

    return redirect(url_for('admin.admin_dashboard', user_id=user_id))

