from flask import Flask

import os
import secrets
import pymssql

class Config:
    
    # Flask Core Configuration
    SECRET_KEY = secrets.token_hex(32)
    USER_APP_NAME = 'PAYROLL'

    DEBUG = False
    TESTING = False
    WTF_CSRF_SECRET_KEY = secrets.token_hex(32)
    WTF_CSRF_ENABLED = False  # Ensure this is not set to False

    # Database Configuration
    #SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'mysql+mysqlconnector://root:Invincible0!@localhost/app'
    
    SQLALCHEMY_DATABASE_URI = 'mssql+pymssql://sa:Administrator0!@sql_server/payroll'
    #mssql sql_server connection configuration
    SQLALCHEMY_DATABASE_USER='sa'
    SQLALCHEMY_DATABASE_PASSWORD='Administrator0!'
    SQLALCHEMY_DATABASE_DB ='payroll'
    

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Email Configuration 
    MAIL_SERVER = 'smtp.office365.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'mishesbone@roboteknologies.org'
    MAIL_PASSWORD = 'ItsBone0!'
    MAIL_DEFAULT_SENDER = 'mishesbone@roboteknologies.org'
    USER_EMAIL_SENDER_EMAIL = 'mishesbone@roboteknologies.org'
    USE_SESSION_FOR_NEXT = True
    MAIL_USE_SSL = False

    # Flask-Login Configuration
    SESSION_PROTECTION = 'strong'  # 'basic', 'strong', or None
    REMEMBER_COOKIE_NAME = 'remember_token'
    REMEMBER_COOKIE_DURATION = 604800  # 1 week in seconds

    # Application-specific Configuration
    STRIPE_SECRET_KEY = 'sk_test_51NfBipDjqt0tSwndh7mgqMqEyU6vTxslFuO5ZYD5wN493u6sN3reMgO5hqgl0Z6q9GyayibY7AdtnZaSGMmN5kim009SMdGZRD'
    # Add other application-specific settings here

    # File Uploads Configuration
    UPLOAD_FOLDER = 'uploads'
    ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'gif'}

    # Pagination Configuration
    ITEMS_PER_PAGE = 10

    # Logging Configuration
    LOG_FILE = 'app.log'

    # Redis Configuration (if using Redis for caching or other purposes)
    REDIS_URL = 'redis://localhost:6379/0'

    # Add more configurations as needed

    # Secret Key Configuration
    SECRET_KEY = secrets.token_hex(32)

    #establishing mysql_server database connection
    from flask import current_app

    def get_db_connection():
        return pymssql.connect(
            server=current_app.config['SQLALCHEMY_DATABASE_URI'],
            user=current_app.config['SQLALCHEMY_DATABASE_USER'],
            password=current_app.config['SQLALCHEMY_DATABASE_PASSWORD'],
            database=current_app.config['SQLALCHEMY_DATABASE_DB']
        )



class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'mysql+mysqlconnector://root:Invincible0!@localhost/app'

class ProductionConfig(Config):
    # Add production-specific configurations here
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = 'mssql+pymssql://sa:Administrator0!@sql_server/payroll'

    #SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'mysql+mysqlconnector://root:Invincible0!@localhost/app'
# Choose the appropriate configuration based on the environment variable
config_map = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
}

# Get the configuration based on the FLASK_ENV environment variable
config_name = os.environ.get('FLASK_ENV', 'development')
app_config = config_map[config_name]
