# Import necessary modules
from functools import wraps
from flask import flash, redirect, url_for, request
from app.models import User, Company
from flask_login import current_user

# Custom decorator to check if the user belongs to the specified company
def user_belongs_to_company(func):
    @wraps(func)
    def decorated_function(*args, **kwargs):
        if current_user.is_authenticated and current_user.company_id == kwargs.get('company_id'):
            return func(*args, **kwargs)
        else:
            flash("You don't have access to this company's data.", 'danger')
            user_id = kwargs.get('user_id')
            return redirect(url_for('auth.index', user_id=current_user.id))
    return decorated_function
