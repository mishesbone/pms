#run.py
from app import create_app, db
from flask.cli import FlaskGroup

# Create an instance of the Flask application
app = create_app()

# Create a Flask CLI Group to add custom commands
cli = FlaskGroup(create_app=create_app)

# Import your models if necessary
from app.models import Level, Grade, Position, Department, Role, Permission

# Define a custom CLI command for database initialization
@cli.command("init_db")
def initialize_database():
    """Initialize the database."""
    with app.app_context():
        db.create_all()
        # Create default levels, grades, and positions
        default_levels = Level.create_defaults()
        default_grades = Grade.create_defaults()
        default_positions = Position.create_defaults()
        default_departments=Department.create_defaults()
        default_roles_and_permissions=Role.create_defaults()
        
        # Commit the changes to the database
        db.session.commit()
    print("Database initialized")

if __name__ == '__main__':
    cli()
